package com.restmic.ex4restmic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ex4restmicApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ex4restmicApplication.class, args);
	}

}
