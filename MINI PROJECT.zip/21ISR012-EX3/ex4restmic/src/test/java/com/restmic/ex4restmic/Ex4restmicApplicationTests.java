package com.restmic.ex4restmic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex4restmicApplicationTests {

	@Test
	void contextLoads() {
	}

}
